﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace skdgraduatesprogramtstseleniumcsharp.Browser
{
    public class DriverFactory
    {
        public static IWebDriver Driver = null;

        public static IWebDriver GetChromeDriver()
        {
            if(Driver == null)
            {
                Driver = new ChromeDriver();

                return Driver;
            }

            return Driver;
        }

        public static void DestroyDriver()
        {
            Driver.Quit();
            Driver = null;
        }
    }
}
