﻿using Microsoft.IdentityModel.Protocols;
using System;
using System.Configuration;

namespace skdgraduatesprogramtstseleniumcsharp
{
    public class ConfigReader
    {
        public static string BASE_URL = ConfigurationManager.AppSettings["BaseUrl"];
        public static int GLOBAL_WAIT_TIMEOUT = Convert.ToInt32(ConfigurationManager.AppSettings["GlobalWaitTimeout"]);
    }
}
