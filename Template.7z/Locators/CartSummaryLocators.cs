﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace skdgraduatesprogramtstseleniumcsharp.Locators
{
    internal class CartSummaryLocators
    {

        public static By checkoutButton = By.CssSelector(".snipcart__cart__actions");
        public static By firstItemHeader = By.CssSelector(".snipcart__item__line__header__title");
        public static By firstItemDescription = By.CssSelector(".snipcart__item__line__description");
        public static By firstItemPrice = By.XPath("//div[@class='snipcart__item__line--flex']//div[2]");
        public static By firstItemDeleteButton = By.CssSelector(".snipcart__button--icon");
        public static By firstItemPlusButton = By.CssSelector(".snipcart__item__line__field__quantity__button");
        public static By cartEmptyLabel = By.CssSelector(".snipcart__cart__content__empty__title");

    }
}
