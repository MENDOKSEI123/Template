﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using skdgraduatesprogramtstseleniumcsharp.Browser;
using System;
using System.Collections.ObjectModel;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    public class BasePage
    {
        private readonly IWebDriver Driver;
        private readonly WebDriverWait Wait;

        public BasePage()
        {
            Driver = DriverFactory.GetChromeDriver();
            Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(ConfigReader.GLOBAL_WAIT_TIMEOUT));
        }

        protected IWebElement GetElement(By by)
        {
            WaitForElementToExist(by);
            WaitForElementToBeVisible(by);

            return Driver.FindElement(by);
        }

        protected ReadOnlyCollection<IWebElement> GetElements(By by)
        {
            WaitForElementsToBePresent(by);

            return Driver.FindElements(by);
        }

        protected void WaitForElementToBeVisible(By by)
        {
            Wait.Until(ExpectedConditions.ElementIsVisible(by));
        }

        protected void WaitForElementToExist(By by)
        {
            Wait.Until(ExpectedConditions.ElementExists(by));
        }

        protected void WaitForElementsToBePresent(By by)
        {
            Wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(by));
        }

        protected void WaitForElementTextToBe(IWebElement element, string text)
        {
            Wait.Until(ExpectedConditions.TextToBePresentInElement(element, text));
        }
    }
}
