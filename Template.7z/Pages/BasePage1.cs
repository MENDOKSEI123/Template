﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using skdgraduatesprogramtstseleniumcsharp.Browser;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    internal class BasePage1
    {
        protected readonly IWebDriver Driver;
        private readonly WebDriverWait Wait;

        public BasePage1()
        {
            Driver = DriverFactory.GetChromeDriver();
            Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(ConfigReader.GLOBAL_WAIT_TIMEOUT));
        }

        protected void WaitUntilVisible(By locator)
        {
            Wait.Until(ExpectedConditions.ElementExists(locator));
            Wait.Until(ExpectedConditions.ElementToBeClickable(locator));
            Wait.Until(ExpectedConditions.ElementIsVisible(locator));
        }

        protected IWebElement GetElementWhenVisible(By locator)
        {
            WaitUntilVisible(locator);
            return Driver.FindElement(locator);
        }

    }
}
