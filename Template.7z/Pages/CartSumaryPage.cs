﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using skdgraduatesprogramtstseleniumcsharp.Locators;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    internal class CartSumaryPage : BasePage1
    {

        public void WaitUntilLoaded()
        {
            WaitUntilVisible(CartSummaryLocators.checkoutButton);
            WaitUntilVisible(CartSummaryLocators.firstItemHeader);
            WaitUntilVisible(CartSummaryLocators.firstItemDescription);
            WaitUntilVisible(CartSummaryLocators.firstItemPlusButton);
        }

        public IWebElement GetFirstItemHeader()
        {
            return GetElementWhenVisible(CartSummaryLocators.firstItemHeader);
        }

        public IWebElement GetFirstItemDescription()
        {
            return GetElementWhenVisible(CartSummaryLocators.firstItemDescription);
        }

        public IWebElement GetFirstItemPrice()
        {
            return GetElementWhenVisible(CartSummaryLocators.firstItemPrice);
        }

        public void ClickFirstDeleteButton()
        {
            IWebElement deleteButton = GetElementWhenVisible(CartSummaryLocators.firstItemDeleteButton);
            deleteButton.Click();
        }

        public IWebElement GetCartEmptyLabel()
        {
            return GetElementWhenVisible(CartSummaryLocators.cartEmptyLabel);
        }

    }
}
