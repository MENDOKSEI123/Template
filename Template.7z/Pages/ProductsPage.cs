﻿using OpenQA.Selenium;
using System.Collections.ObjectModel;
using System.Linq;
using skdgraduatesprogramtstseleniumcsharp.Locators;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    public class ProductsPage : BasePage
    {
        private ReadOnlyCollection<IWebElement> Products => GetElements(ProductLocators.productsLocator);
        private IWebElement ViewCartButton => GetElement(By.CssSelector("button[class='snipcart-checkout']"));

        public void AddProductWithName(string productName)
        {
            Products.FirstOrDefault(x => x.FindElement(By.TagName("h3")).Text.Equals(productName)).FindElement(By.TagName("button")).Click();
        }

        public void ClickViewCartButton()
        {
            ViewCartButton.Click();
        }
    }
}
