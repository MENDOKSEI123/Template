﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    internal class ProductsPage1 : BasePage1
    {

        public IWebElement GetAddToCartButton(String itemName)
        {
            By locator = By.XPath($"//button[@data-item-name='{itemName}']");
            return GetElementWhenVisible(locator);
        }
    }
}
