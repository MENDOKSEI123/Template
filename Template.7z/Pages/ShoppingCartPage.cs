﻿using OpenQA.Selenium;
using System.Collections.ObjectModel;

namespace skdgraduatesprogramtstseleniumcsharp.Pages
{
    public class ShoppingCartPage : BasePage
    {
        private ReadOnlyCollection<IWebElement> ShoppingCartProducts => GetElements(By.CssSelector("li[class='snipcart__item__line snipcart__box']"));
        private IWebElement ShoppingCartProductCounter => GetElement(By.ClassName("snipcart__modal__header__count"));
        private IWebElement ContinueShoppingButton => GetElement(By.CssSelector("button[class='snipcart__modal__close']"));
        private IWebElement CartAmount => GetElement(By.ClassName("snipcart__cart__summary__lines__amount"));

        public void CleanShoppingCart()
        {
            if(ShoppingCartProductCounter.Text != "0")
            {
                foreach (var item in ShoppingCartProducts)
                {
                    item.FindElement(By.CssSelector("button[class='snipcart__button--icon']")).Click();
                }

                WaitForShoppingCartProductCounterToBe("0");
            }
        }

        public ReadOnlyCollection<IWebElement> GetShoppingCartProducts()
        {
            return ShoppingCartProducts;
        }

        public void ClickContinueShoppingButton()
        {
            ContinueShoppingButton.Click();
        }

        public void WaitForShoppingCartProductCounterToBe(string counter)
        {
            WaitForElementTextToBe(ShoppingCartProductCounter, counter);
        }

        public void WaitForShoppingCartAmountToBe(string amount)
        {
            WaitForElementTextToBe(CartAmount, amount);
        }
    }
}
