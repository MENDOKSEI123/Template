﻿using System;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using skdgraduatesprogramtstseleniumcsharp.Browser;

namespace skdgraduatesprogramtstseleniumcsharp.Tests
{
    public class BaseTest
    {
        public static ExtentReports extent;
        public static ExtentTest test;
        private IWebDriver Driver;

        [TearDown]
        protected void TearDown()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stackTrace = $"{TestContext.CurrentContext.Result.StackTrace}";
            var errorMessage = TestContext.CurrentContext.Result.Message;

            switch(status)
            {
                case TestStatus.Failed:
                    string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
                    string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));
                    string projectPath = new Uri(actualPath).LocalPath;
                    string screenshotPath = $"{projectPath}Reports\\Screenshots\\{TestContext.CurrentContext.Test.Name}.png";

                    Screenshot s = ((ITakesScreenshot)Driver).GetScreenshot();
                    s.SaveAsFile(screenshotPath, ScreenshotImageFormat.Png);

                    test.AddScreenCaptureFromPath(screenshotPath);
                    test.Log(Status.Fail, errorMessage);
                    extent.AddTestRunnerLogs(stackTrace);
                    break;
                case TestStatus.Passed:
                    test.Log(Status.Pass);
                    break;
                case TestStatus.Skipped:
                    test.Log(Status.Skip);
                    break;
                case TestStatus.Inconclusive:
                    test.Log(Status.Info);
                    break;
                case TestStatus.Warning:
                    test.Log(Status.Warning);
                    break;
            }

            AfterEach();
            DriverFactory.DestroyDriver();
        }

        [OneTimeTearDown]
        protected void OneTimeTearDown()
        {
            extent.Flush();
            AfterAll();
        }
        
        [SetUp]
        protected void SetUp()
        {
            test = extent.CreateTest(TestContext.CurrentContext.Test.Name);

            Driver = DriverFactory.GetChromeDriver();
            Driver.Manage().Window.Maximize();
            Driver.Navigate().GoToUrl(ConfigReader.BASE_URL);
            BeforeEach();
        }

        [OneTimeSetUp]
        protected void OneTimeSetUp()
        {
            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));
            string projectPath = new Uri(actualPath).LocalPath;

            string reportPath = projectPath + "Reports\\TestRunReport.html";
            extent = new ExtentReports();
            var reporter = new ExtentHtmlReporter(reportPath);
            extent.AttachReporter(reporter);
            BeforeAll();
        }

        protected virtual void AfterEach()
        {

        }

        protected virtual void AfterAll()
        {

        }

        protected virtual void BeforeEach()
        {

        }

        protected virtual void BeforeAll()
        {

        }
    }
}
