﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using skdgraduatesprogramtstseleniumcsharp.Pages;

namespace skdgraduatesprogramtstseleniumcsharp.Tests
{
    [TestFixture]
    internal class DemoTest : BaseTest
    {

        private ProductsPage1 productsPage;
        private CartSumaryPage cartSummaryPage;
        
        [SetUp]
        public void Setup()
        {
            productsPage = new ProductsPage1();
            cartSummaryPage = new CartSumaryPage();
        }

        [Test]
        public void demo1Test()
        {
            IWebElement addToCartButton = productsPage.GetAddToCartButton("Cadbury Caramello Koala Share Pack");
            addToCartButton.Click();

            cartSummaryPage.WaitUntilLoaded();

            IWebElement itemPriceElement = cartSummaryPage.GetFirstItemPrice();
            IWebElement itemHeaderElement = cartSummaryPage.GetFirstItemHeader();
            IWebElement itemDescriptionElement = cartSummaryPage.GetFirstItemDescription();

            Assert.That(itemHeaderElement.Text, Is.EqualTo("Cadbury Caramello Koala Share Pack"));
            Assert.That(itemDescriptionElement.Text, Is.EqualTo("Perfect for sharing or snacking!"));
            Assert.That(itemPriceElement.Text, Is.EqualTo("$5.99"));
        }

        [Test]
        public void demo2Test()
        {
            IWebElement addToCartButton = productsPage.GetAddToCartButton("Cadbury Caramello Koala Share Pack");
            addToCartButton.Click();

            cartSummaryPage.WaitUntilLoaded();
            cartSummaryPage.ClickFirstDeleteButton();

            IWebElement cartEmptyLabel = cartSummaryPage.GetCartEmptyLabel();


            //Assert.That(cartEmptyLabel.Displayed, Is.True);
            Assert.That(false, Is.True);
        }
    }
}
