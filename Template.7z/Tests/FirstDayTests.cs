﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using skdgraduatesprogramtstseleniumcsharp.Browser;
using skdgraduatesprogramtstseleniumcsharp.Pages;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace skdgraduatesprogramtstseleniumcsharp.Tests
{
    [TestFixture]
    public class FirstDayTests : BaseTest
    {
        

        [Test]
        public void SearchTerm()
        {
            IWebDriver Driver = DriverFactory.GetChromeDriver();
            WebDriverWait Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(ConfigReader.GLOBAL_WAIT_TIMEOUT));

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61showButton")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61showButton")));
            IWebElement Search = Driver.FindElement(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61showButton"));
            Search.Click();

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61mainSearch")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61mainSearch")));
            IWebElement SearchTerm = Driver.FindElement(By.Id("3024E825-2134-482B-94F5-4F14BAF7BA61mainSearch"));
            SearchTerm.SendKeys("water");

            Wait.Until(ExpectedConditions.ElementIsVisible(By.ClassName("clickButtonFederatedSearch")));
            Wait.Until(ExpectedConditions.ElementExists(By.ClassName("clickButtonFederatedSearch")));
            IWebElement Result = Driver.FindElement(By.ClassName("clickButtonFederatedSearch"));
            Result.Click();

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("btnArticlesAndAbstracts")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("btnArticlesAndAbstracts")));
            IWebElement Abstract = Driver.FindElement(By.Id("btnArticlesAndAbstracts"));
            Abstract.Click();

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("ddlTypeOfContent")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("ddlTypeOfContent")));
            IWebElement Filter = Driver.FindElement(By.Id("ddlTypeOfContent"));
            Filter.Click();

            /*Wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("ddlTypeOfContent")));
            Wait.Until(ExpectedConditions.ElementExists(By.XPath("ddlTypeOfContent")));
            IWebElement Option = Driver.FindElement(By.XPath("ddlTypeOfContent"));
            Option.Click(); */ //-> ke raboti so xpath.





        }
        [Test]
        public void OpenArticle()
        {
            IWebDriver Driver = DriverFactory.GetChromeDriver();
            WebDriverWait Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(ConfigReader.GLOBAL_WAIT_TIMEOUT));



        }
        
        [Test]
        public void Login()
        {
            IWebDriver Driver = DriverFactory.GetChromeDriver();
            WebDriverWait Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(ConfigReader.GLOBAL_WAIT_TIMEOUT));

            Wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText("Login")));
            Wait.Until(ExpectedConditions.ElementExists(By.LinkText("Login")));
            IWebElement Login = Driver.FindElement(By.LinkText("Login"));
            Login.Click();

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("floatingLabelInput18")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("floatingLabelInput18")));
            IWebElement Email = Driver.FindElement(By.Id("floatingLabelInput18"));
            Email.SendKeys("Test.Forgerock018@agu.org");

            Wait.Until(ExpectedConditions.ElementIsVisible(By.ClassName("btn")));
            Wait.Until(ExpectedConditions.ElementExists(By.ClassName("btn")));
            IWebElement Next = Driver.FindElement(By.ClassName("btn"));
            Next.Click();

            Wait.Until(ExpectedConditions.ElementIsVisible(By.Id("floatingLabelInput24")));
            Wait.Until(ExpectedConditions.ElementExists(By.Id("floatingLabelInput24")));
            IWebElement Pass = Driver.FindElement(By.Id("floatingLabelInput24"));
            Pass.SendKeys("Password1");

            Wait.Until(ExpectedConditions.ElementIsVisible(By.ClassName("btn")));
            Wait.Until(ExpectedConditions.ElementExists(By.ClassName("btn")));
            IWebElement Next2 = Driver.FindElement(By.ClassName("btn"));
            Next2.Click();



        }
    }
}
