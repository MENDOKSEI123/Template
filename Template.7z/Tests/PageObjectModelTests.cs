﻿using NUnit.Framework;
using skdgraduatesprogramtstseleniumcsharp.Pages;

namespace skdgraduatesprogramtstseleniumcsharp.Tests
{
    [TestFixture]
    public class PageObjectModelTests : BaseTest
    {
        private ProductsPage ProductsPage => new ProductsPage();
        private ShoppingCartPage ShoppingCartPage => new ShoppingCartPage();

        protected override void BeforeEach()
        {
            ProductsPage.ClickViewCartButton();
            ShoppingCartPage.CleanShoppingCart();
            ShoppingCartPage.ClickContinueShoppingButton();
        }

        [Test]
        public void VerifyThatProductCanBeAddedToShoppingCart()
        {
            ProductsPage.AddProductWithName("Cadbury Caramello Koala Share Pack 5.99$");
            ShoppingCartPage.WaitForShoppingCartProductCounterToBe("1");
            ShoppingCartPage.WaitForShoppingCartAmountToBe("$5.99");

            Assert.IsTrue(ShoppingCartPage.GetShoppingCartProducts().Count.Equals(1));
        }

        [Test]
        public void VerifyThatMultipleProductsCanBeAddedToShoppingCart()
        {
            ProductsPage.AddProductWithName("Cadbury Caramello Koala Share Pack 5.99$");
            ShoppingCartPage.WaitForShoppingCartProductCounterToBe("1");
            ShoppingCartPage.WaitForShoppingCartAmountToBe("$5.99");

            Assert.IsTrue(ShoppingCartPage.GetShoppingCartProducts().Count.Equals(1));

            ShoppingCartPage.ClickContinueShoppingButton();
            ProductsPage.AddProductWithName("Caixa De Bombons Sortidos Garoto 49$");
            ShoppingCartPage.WaitForShoppingCartProductCounterToBe("2");
            ShoppingCartPage.WaitForShoppingCartAmountToBe("$54.99");

            Assert.IsTrue(ShoppingCartPage.GetShoppingCartProducts().Count.Equals(2));
        }
    }
}
